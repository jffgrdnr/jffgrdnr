// Use this as a quick template for future modules
define([
  'jquery',
  'underscore',
  'backbone'
], function($, _, Backbone){

  return {};
});
