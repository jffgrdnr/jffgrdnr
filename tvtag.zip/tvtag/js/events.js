define([
  'jquery',
  'underscore',
  'backbone'
], function($, _, Backbone){
  var vent = _.extend({}, Backbone.Events);
  return vent;
});