# tvtag app
This is a mock-up app for tvtag, using a mock/test rest call, Backbone, Node, Bootstrap, and a Backbone Boilerplate

## Other resources

[http://backbonetutorials.com](http://backbonetutorials.com) - As single page apps and large scale javascript applications become more prominent on the web, useful resources for those developers who are jumping the ship are crucial.

## About the author

**Contact:**

*   [@jffgrdnr](http://twitter.com/jffgrdnr) on twitter
*   Github - https://github.com/jffgrdnr
*   jeffreywgardner@gmail.com

**Projects:**

*   StackOverflow - http://stackoverflow.com/users/610295/jffgrdnr

