# UX Standards Proposal App

UX Standards Proposal App

--------------------------

This demo app was built for the UX team for submitting new standards proposals


RUN: npm start (this will run "node server.js" and "webpack-dev-server" concurrently)


