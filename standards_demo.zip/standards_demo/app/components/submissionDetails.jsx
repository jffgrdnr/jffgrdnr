// component option
import React, { Component } from 'react';

class SubmissionDetails extends Component {
	constructor(props) {
		super(props);
		this.state = {
			submission: []
		}
	}
	render() {
	    return (
	    	<div>
		      {this.state.submission.map((sub, index) => (
		      	<div key={index} className="backlogItem">
			      	<h3 className="icon iconNote">{sub.submission_title}</h3>
			        <ul className="iconFlushText">
			        	<li>
			        		Submitted: <span className="bold">{sub.submission_date}</span>
			        	</li>
			        	<li>
			        		Designer: <span className="bold">{sub.designer_name}</span>
			        	</li>
			        	<li>
			        		Feedback: <span className="bold">{sub.slack_takeaways}</span>
			        	</li>
			        	<li>
			        		Pain Points: <span className="bold">{sub.fed_pain_points}</span>
			        	</li>
			        	<li>
			        		Impact: <span className="bold">{sub.submission_impact}</span>
			        	</li>
			        	<li>
			        		Purpose: <span className="bold">{sub.submission_purpose}</span>
			        	</li>
			        </ul>
			        <hr className="conDivider topSpacingBlock" />
			      </div>
		      ))}
		      </div>
	     	
	    );
  	}
}

module.exports = SubmissionDetails
