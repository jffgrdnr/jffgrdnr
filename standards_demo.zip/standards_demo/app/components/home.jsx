// component option
import React, { Component } from 'react';
import ComponentBacklog from './componentBacklog.jsx';

class Home extends Component {
	constructor(props) {
		super(props);
		this.state = {
			submission: []
		}
	}
	render() {
	    return (
	      <div>
	      	<div className="topSpacingBlock">
	      		Are you at the point in your project where you need to make a proposal to the design standards? Then you are in the right place. You can find a backlog of all the requests in process, and forms to propose your designs. 
	      	</div>
	        <div className="con">
				<header className="conHeader">
				  <h1 className="conTitle">UI Standards Backlog</h1>
				  <a href="https://confluence.mfsbe.com/display/PH/UI+Standards+Backlog" target="_blank" rel="noopener noreferrer">https://confluence.mfsbe.com/display/PH/UI+Standards+Backlog</a>
				  <hr className="conDivider" />
				</header>
				<div className="conBody">
				  This is a running list, and as of this editing, has not been prioritized. A checked item means that this item has been reviewed and approved for implementation. If you make a proposal it will appear in this list.
				</div>
				<hr className="conDivider" />
				<ComponentBacklog/>
			</div>
	      </div>
	    );
  	}
}

module.exports = Home