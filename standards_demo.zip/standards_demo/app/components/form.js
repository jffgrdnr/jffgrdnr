import React, { Component } from 'react';

class Form extends Component {

	getSubmissionDate() {
		let dateObject = new Date(), 
			newMonth = dateObject.getMonth() + 1,
			newDay = dateObject.getDate(),
			newYear = dateObject.getUTCFullYear(),
			submission_date =`${newMonth}/${newDay}/${newYear}`;	
		return submission_date
	}
		
	handleSubmit(event) {
		event.preventDefault();

		/* extract data */
		const inputs = event.target.elements;
		const data = {};

		for (let i = 0; i < inputs.length; ++i) {
            const input = inputs.item(i);
            if (input.type === 'radio' && input.checked) {
                data[input.name] = input.value;
            } else if (input.type !== 'radio') {
                data[input.name] = input.value;
            }
        }

        data.submission_date = this.getSubmissionDate();
        
		/* send to parent */
		this.props.handleSubmit(data);
	}
	render() {
		let dateObject = new Date(), 
			newMonth = dateObject.getMonth() + 1,
			newDay = dateObject.getDate(),
			newYear = dateObject.getUTCFullYear(),
			submission_date =`${newMonth}/${newDay}/${newYear}`;
		return (
			<form className="form" onSubmit={this.handleSubmit.bind(this)}>
				{this.props.children}
			</form>
		)
	}
}

export default Form;