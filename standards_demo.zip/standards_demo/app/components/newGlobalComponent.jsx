// new global component
import React, { Component } from 'react';
import Form from './form';

class NewGlobalComponent extends Component{
	render() {
	    return (
	      <div className="componentPage">
	      	<div className="ancCol w100 ancColRow topSpacingBlock">
	      		<header>
	        		<h1>Proposing a new global component</h1>
	        	</header>
	        	<p>A new global component is something that is not currently in use on Ansestry, or you may have noticed design work-arounds being used currently.</p>
	        </div>
	        <hr className="conDivider" />
	        <Form handleSubmit={this.props.handleSubmit}>
		        <ol>
		        	<li>
		        		<header className="ancCol w100 ancColRow">
		        			<h2>1. Slack channel feedback</h2>
		        		</header>
		        		<div className="ancCol w100">
		        			<p>Before you submit an idea for a global revision, post an image of your idea in the <strong>#standards_team</strong> Slack channel</p>
		        		</div>
		        		<fieldset className="ancCol w100 topSpacingBlock">
							<label className="required" id="myCollection2" data-error="More!!!">Did you submit your idea(s) on the Standards Slack Channel?</label>
							<div className="ancGrid">
								<div className="ancCol w10">
									<input id="slackYes" type="radio" name="slack_feedback_received" className="radio" value="yes" />
									<label htmlFor="slackYes">Yes</label>
								</div>
								<div className="ancCol w10">
									<input id="slackNo" type="radio" name="slack_feedback_received" className="radio" value="no" defaultChecked />
									<label htmlFor="slackNo">No</label>
								</div>
							</div>
						</fieldset>
						<div className="ancCol w100 ancColRow">
							<label htmlFor="slack_takeaways">What were the key takeaways from Slack?</label>
							<textarea className="textareaLarge" id="slack_takeaways" name="slack_takeaways"></textarea>
						</div>
						<div className="ancCol w100 ancColRow">
							<label htmlFor="fed_pain_points">What are the pain points discussed with the FED team?</label>
							<textarea className="textareaLarge" id="fed_pain_points" name="fed_pain_points"></textarea>
						</div>
						<div className="ancCol w100 ancColRow">
							<label htmlFor="submission_impact">How big of a change does your proposal have?</label>
							<textarea className="textareaLarge" id="submission_impact" name="submission_impact"></textarea>
						</div>
						<hr className="conDivider topSpacingBlock" />
		        	</li>
		        	<li>
		        		<header>
		        			<h2>2. Answer a few questions</h2>
		        		</header>
		        		<div className="ancCol w100 ancColRow">
							<label htmlFor="submission_purpose">Can you explain why this proposal is needed?</label>
							<textarea className="textareaLarge" id="submission_purpose" name="submission_purpose"></textarea>
						</div>
						<div className="ancCol w100 ancColRow">
							<p>Are there current design workarounds to show? Upload them here:</p>
							<div aria-pressed="false" className="card cardEmpty textCenter topSpacingBlock" role="button" tabIndex="0" data-toggle-classes="cardOutline2 cardSelected" id="design_workarounds" name="design_workarounds">
								<div className="cardEmptyAction textCenter icon iconGallery">Upload media</div>
							</div>
						</div>
						<hr className="conDivider topSpacingBlock" />
		        	</li>
		        	<li>
		        		<header>
		        			<h2>3. Upload your proposal mocks</h2>
		        		</header>
		        		<div className="ancCol w100 ancColRow">
							<p>Submit any mocks, patterns and flows you have with details of the different states considered for implementation.</p>
							<div aria-pressed="false" className="card cardEmpty textCenter topSpacingBlock" role="button" tabIndex="0" data-toggle-classes="cardOutline2 cardSelected" id="submission_mocks">
								<div className="cardEmptyAction textCenter icon iconGallery">Upload media</div>
							</div>
						</div>
						<hr className="conDivider topSpacingBlock" />
		        	</li>
		        	<li>
		        		<div className="ancCol w50">
		        			<label htmlFor="designer_name">Your Name</label>
		        			<input id="designer_name" name="designer_name" type="text"/>
		        		</div>
		        		<div className="ancCol w50">
		        			<label htmlFor="designer_email">Your Email</label>
		        			<input id="designer_email" name="designer_email" type="text"/>
		        		</div>
		        		<div className="ancCol w100 ancColRow">
		        			<label htmlFor="submission_title">What would you like to name your proposal?</label>
		        			<input id="submission_title" name="submission_title" type="text" />
		        		</div>
		        	</li>
		        </ol>
		        <div className="ancCol w100 ancColRow topSpacingBlock">
		        	<p>Once your proposal is submitted, it will be reviewed by our UX Standards committee which meets to determine if your proposal will be approved or declined.</p>
		        </div>
		        <div className="proposalSubmit ancCol w100 ancColRow topSpacingBlock">
		        	<input type="hidden" id="submission_type" name="submission_type" value="New Global Component" />
		        	<input type="hidden" id="submission_status" name="submission_status" value="Submitted" />
		        	<input type="hidden" id="submission_date" name="submission_date" value="" />
		        	<button className="ancBtn lrg" type="submit" value="Submit">Submit Proposal</button>
		        </div>
	        </Form>
	      </div>
	    );
  	}
}

export default NewGlobalComponent