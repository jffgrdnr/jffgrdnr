// Custom Component
import React, { Component } from 'react';
import Form from './form';

class CustomComponent extends Component {
	render() {
	    return (
	      <div className="componentPage">
	      	<div className="ancCol w100 ancColRow topSpacingBlock">
	      		<header>
	      			<h1>Proposing a Custom Component</h1>
	      		</header>
	        
	        	<p>You might find that the global components may not be able to be applied to your design. In this case, propose your custom design or element so the Standards committee is aware of it. You never know, maybe your custom component will become a global component someday. Examples of custom components are:</p>
		        <ul className="headerList">
		        	<li>The Merge Flow widget</li>
		        	<li>The DNA Circle graph</li>
		        	<li>The Purple connection lines on the Person Page</li>
		        	<li>The DNA Match List filters</li>
		        </ul>
		    </div>
	        <hr className="conDivider topSpacingBlock" />
	        <Form className="form" handleSubmit={this.props.handleSubmit}>
		        <ol>
		        	<li>
		        		<header className="ancCol w100 ancColRow">
		        			<h2>1. Answer a few questions</h2>
		        		</header>
		        		<div className="ancCol w100">
							<label htmlFor="submission_purpose">Can you explain why this proposal is needed?</label>
							<textarea className="textareaLarge" id="submission_purpose" name="submission_purpose"></textarea>
						</div>
						<fieldset className="ancCol w100 topSpacingBlock">
							<label className="required" data-error="More!!!">Are there similar components found on Ancestry?</label>
							<div className="ancGrid">
								<div className="ancCol w10">
									<input id="similarYes" type="radio" name="has_similar_components" className="radio" value="yes" />
									<label htmlFor="similarYes">Yes</label>
								</div>
								<div className="ancCol w10">
									<input id="similarNo" type="radio" name="has_similar_components" className="radio" value="no" defaultChecked />
									<label htmlFor="similarNo">No</label>
								</div>
							</div>
						</fieldset>
						<div className="ancCol w100 ancColRow">
							<p>If you answered yes, please upload screenshots of the exisiting options.</p>
							<div aria-pressed="false" className="card cardEmpty textCenter topSpacingBlock" role="button" tabIndex="0" data-toggle-classes="cardOutline2 cardSelected" name="existing_options">
								<div className="cardEmptyAction textCenter icon iconGallery">Upload media</div>
							</div>
						</div>
						<hr className="conDivider topSpacingBlock" />
		        	</li>
		        	<li>
		        		<header>
		        			<h2>2. Upload your proposal mocks</h2>
		        		</header>
		        		<div className="ancCol w100 ancColRow">
		        			<p>Submit any mocks, patterns and flows you have with details of the different states considered for implementation.</p>
		        		</div>
		        		<div className="ancCol w100 ancColRow">
							<div aria-pressed="false" className="card cardEmpty textCenter topSpacingBlock" role="button" tabIndex="0" data-toggle-classes="cardOutline2 cardSelected" name="submission_mocks">
								<div className="cardEmptyAction textCenter icon iconGallery">Upload media</div>
							</div>
						</div>
						<hr className="conDivider topSpacingBlock" />
		        	</li>
		        	<li>
		        		<div className="ancCol w50">
		        			<label htmlFor="designer_name">Your Name</label>
		        			<input id="designer_name" name="designer_name" type="text" />
		        		</div>
		        		<div className="ancCol w50">
		        			<label htmlFor="designer_email">Your Email</label>
		        			<input id="designer_email" name="designer_email" type="text" />
		        		</div>
		        		<div className="ancCol w100 ancColRow">
		        			<label htmlFor="submission_title">What would you like to name your proposal?</label>
		        			<input id="submission_title" name="submission_title" type="text" />
		        		</div>
		        	</li>
		        </ol>
		        <div className="ancCol w100 ancColRow topSpacingBlock">
		        	<p>Once your proposal is submitted, it will be reviewed by our UX Standards committee which meets to determine if your proposal will be approved or declined.</p>
		        </div>
		        <div className="proposalSubmit ancCol w100 ancColRow topSpacingBlock">
		        	<input type="hidden" id="submission_type" name="submission_type" value="Custom Component" />
		        	<input type="hidden" id="submission_status" name="submission_status" value="Submitted" />
		        	<input type="hidden" id="submission_date" name="submission_date" value="" />
		        	<button className="ancBtn lrg" type="submit" value="Submit">Submit Proposal</button>
		        </div>
	        </Form>
	      </div>
	    );
  	}
}

export default CustomComponent