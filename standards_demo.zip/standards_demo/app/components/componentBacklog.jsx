// component option
import React, { Component } from 'react';
import axios from 'axios'

class ComponentBacklog extends Component {
	constructor(props) {
		super(props);
		this.state = {
			submission: []
		}
	}
	componentWillMount() {
		this.loadDataFromAxios();
	}

	loadDataFromAxios() {
		const self = this;
		axios.get('http://localhost:3000/api/submissions', {
		})
		.then(function (response) {
			//console.log(response.data);
			self.setState({submission:response.data});
		})
		.catch(function (error) {
			console.log(error);
		});
	}
	render() {
	    return (
	    	<div>
		      {this.state.submission.map((sub, index) => (
		      	<div key={index} className="backlogItem">
			      	<h3 className="icon iconNote">{sub.submission_title}</h3>
			        <ul className="iconFlushText">
			        	<li>
			        		Submitted: <span className="bold">{sub.submission_date}</span>
			        	</li>
			        	<li>
			        		Designer: <span className="bold">{sub.designer_name}</span>
			        	</li>
			        	<li>
			        		Status: <span className="bold">{sub.submission_status}</span>
			        	</li>
			        </ul>
			        <hr className="conDivider topSpacingBlock" />
			      </div>
		      ))}
		      </div>
	     	
	    );
  	}
}

module.exports = ComponentBacklog
