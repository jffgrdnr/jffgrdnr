
// component option
import React, { Component } from 'react';
import axios from 'axios';

class Alert extends Component {
	constructor(props) {
		super(props);
	}

	render() {
    	return (
    		<div>
				<div className={"alert alertNotification alertCloseable " + this.props.alertType + " " + this.props.alertVisible} role="alert" aria-label="Successfully Deleted">
	        		<h4 className="alertTitle">{this.props.alertTitle}</h4>
	        		<button className="closeBtn alertCloseBtn" type="button" title="Close" onClick={this.props.onClick}></button>
	        	</div>
        	</div>
		);
	}
}

export default Alert