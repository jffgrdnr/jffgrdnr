// app/models/submission.js
// grab the mongoose model

const mongoose 	= require('mongoose');
const Schema    = mongoose.Schema;
const crate 	= require('mongoose-crate');
const LocalFS 	= require('mongoose-crate-localfs');


const SubmissionSchema  = new Schema ({
	slack_feedback_received: Boolean,
	slack_takeaways: String,
	fed_pain_points: String,
	submission_impact: String,
	submission_purpose: String,
	research_urls: { type: String },
	has_similar_components: Boolean,
	submission_differences: String,
	designer_name: String,
	designer_email: String,
	submission_title: String,
	submission_type: String,
	submission_date: String,
	submission_status: String,
})

// SubmissionSchema.plugin(crate, {
// 	storage: new LocalFS({
// 		directory: './app/uploads'
// 	}),
// 	fields: {
// 		research_documents: { array: true },
//		design_workarounds: {},
// 		submission_mocks: {},
// 		mocks_in_context: {},
// 		updated_bonsai_file: {},
//		existing_options: {}
// 	}
// })

module.exports = mongoose.model('Submission', SubmissionSchema);