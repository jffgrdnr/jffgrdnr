// Home.jsx

import React from 'react';
import ReactDOM from 'react-dom';
import './App.css';
import axios from 'axios';
import NewGlobalComponent from './components/newGlobalComponent.jsx';
import ComponentOption from './components/componentOption.jsx';
import GlobalRevision from './components/globalRevision.jsx';
import CustomComponent from './components/customComponent.jsx';
import Home from './components/home.jsx';
import Alert from './components/alert.jsx';

class App extends React.Component {
	constructor(props) {
	    super(props);
	    this.state = {
	      tabContent: "Home",
	      alertType: "alert",
	      alertVisible: "alertHidden",
	      alertTitle: "",
	      submission_success: false
	    };
	    this.switchTabs = this.switchTabs.bind(this);
	    this.handleCloseButton = this.handleCloseButton.bind(this);
	    this.handleFormSubmit = this.handleFormSubmit.bind(this);
	}
	
	switchTabs(component,e) {
		e.stopPropagation();
		this.setState({ tabContent : component });
	}

	handleCloseButton(event) {
		event.preventDefault();
		this.setState({alertVisible: "alertHidden"})
		//console.log("close alert");
		//console.log(this.state.alertVisible);
	}

	handleFormSubmit(data) {
		axios.post('http://localhost:3000/api/submissions', data)
  		.then(response => {
  			console.log(response);
  			if (response.status === 200) {
  				//console.log("State after post: ", self.props);
  				this.setState({alertVisible: "", alertType: "alertSuccess", alertTitle: "Submission created"})
  				setTimeout(() => {this.setState({alertVisible: "alertHidden"})}, 5000)
  			}
  		})
  		.catch(function (error) {
			console.log(error);
		})
	}
	render() {
	    return (
	      <div>
	        <main role="main" aria-labelledby="pageTitle">
	          <header className="pageHeader bgColor8">
	            <h1 className="pageTitle">Standards Proposals</h1>
	            <p className="pageIntro">Welcome to the standards components proposal page. What would you like to propose?</p>
	            <nav className="tabs topSpacingBlock" data-tab="pages" role="tablist">
	              <button className={"tab " + (this.state.tabContent === 'Home' ? 'tabActive active' : '')} onClick={(event) => this.switchTabs("Home", event)} role="tab" id="tab0" aria-controls="pagesTabPanel0" aria-selected="true" aria-expanded="true">Home</button>
	              <button className={"tab " + (this.state.tabContent === 'NewGlobalComponent' ? 'tabActive active' : '')} onClick={(event) => this.switchTabs("NewGlobalComponent", event)} role="tab" id="tab1" aria-controls="pagesTabPanel1" aria-selected="false" aria-expanded="false">New Global Component</button>
	              <button className={"tab " + (this.state.tabContent === 'ComponentOption' ? 'tabActive active' : '')} onClick={(event) => this.switchTabs("ComponentOption", event)} role="tab" id="tab2" aria-controls="pagesTabPanel2" aria-selected="false" aria-expanded="false">Component Option</button>
	              <button className={"tab " + (this.state.tabContent === 'GlobalRevision' ? 'tabActive active' : '')} onClick={(event) => this.switchTabs("GlobalRevision", event)} role="tab" id="tab3" aria-controls="pagesTabPanel2" aria-selected="false" aria-expanded="false">Global Revision</button>
	              <button className={"tab " + (this.state.tabContent === 'CustomComponent' ? 'tabActive active' : '')} onClick={(event) => this.switchTabs("CustomComponent", event)} role="tab" id="tab4" aria-controls="pagesTabPanel2" aria-selected="false" aria-expanded="false">Custom Component</button>
	            </nav>
	          </header>
	          <div className="page">
	            <div className="ancGrid full480 ancGridPadded">
	              <div className="article ancCol w100">
	                {(() => {
	                    switch (this.state.tabContent) {
	                        case 'NewGlobalComponent':
	                            return <NewGlobalComponent handleSubmit={this.handleFormSubmit} />
	                        case 'ComponentOption':
	                          return <ComponentOption handleSubmit={this.handleFormSubmit} />
	                        case 'GlobalRevision':
	                          return <GlobalRevision handleSubmit={this.handleFormSubmit} />
	                        case 'CustomComponent':
	                          return <CustomComponent handleSubmit={this.handleFormSubmit} />
	                        default :
	                           return <Home />
	                    }
	                })()}
	              </div>
	            </div>
	            <div id="alertNotifications" className="alertNotifications" aria-live="polite">
	            	<Alert alertType={this.state.alertType} alertVisible={this.state.alertVisible} alertTitle={this.state.alertTitle} onClick={this.handleCloseButton} />
	            </div>
	          </div>
	        </main>
	      </div>
	    );
	  }
	}

ReactDOM.render(<App />, document.getElementById('app'));