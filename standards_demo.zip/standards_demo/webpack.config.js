var path = require('path');

var APP_DIR = path.resolve(__dirname + '/app');

var config = {
	entry: './app/index.jsx',
	devServer: {
		contentBase: "./public",
	},
	output: {
		filename:'bundle.js',
		path:'/public/bundle.js'
	},
	module: {
		loaders: [
			{
				test: /\.jsx?/,
				include: APP_DIR,
				exclude:/(node_modules)/,
				use : {
					loader: 'babel-loader',
					options: {
						presets: ['env']
					}	
				}
			},
			{
		        test: /\.css/,
		        loaders: ['style-loader', 'css-loader'],
		        include: __dirname + '/app'
		      }
		]
	},
};

module.exports = config;