
// server.js

// BASE SETUP
// ============================================================

const express 			= require('express'); 		// call express
const app 				= express();				// define our app using express
const bodyParser 		= require('body-parser');	
const request 			= require('request');
const mongoose 			= require('mongoose');
const methodOverride 	= require('method-override');
const cors    			= require('cors');


// ROUTES FOR OUR API
// =============================================================================
var router = express.Router();              // get an instance of the express Router


// SET UP MONGOOSE
//-------------------------------------------------------------
// grab the packages we need
mongoose.connect('mongodb://localhost/standards_proposal');


// configure app to use bodyParser()
// this will let us get the data from a POST
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());


app.use(cors());

app.get('/submissions',
  findSubmissions,
  getJsonResponse
);

// more routes for our API will happen here

function findSubmissions(req, res, next) {
  const url = `http://localhost:8080/submissions`;
  request(url, handleApiResponse(res, next));
}

function handleApiResponse(res, next) {
  return (err, response, body) => {
    if (err || body[0] === '<') {
      res.locals = {
        success: false,
        error: err || 'Invalid request. Please check your state variable.'
      };
      return next();
    }
    res.locals = {
      success: true,
      results: JSON.parse(body).results
    };
    return next();
  };
}

function getJsonResponse(req, res, next) {
	return res.json(res.locals);
}

var exports = module.exports = {};
exports = {
  jsonResponse: function(req, res, next) {
    return res.json(res.locals);
  }
}


// test route to make sure everything is working (accessed at GET http://localhost:8080/api)
router.get('/', function(req, res) {
    res.sendFile('public/index.html', {root: __dirname});   
});


// more routes for our API will happen here

var Submission     = require('./app/models/submission');

router.route('/submissions')

    // create a submission (accessed at POST http://localhost:8080/api/submissions)
    .post(function(req, res) {

        var submission = new Submission();      // create a new instance of the submission model
        console.log("Request body: ", req.body);
        // set the submissions name (comes from the request)
        submission = Object.assign(submission, req.body);

        // save the submission and check for errors
        submission.save(function(err) {
            if (err)
                res.send(err);

            res.json({ message: 'Submission created!' });
        })

    })

    // get all the submissions (accessed at GET http://localhost:8080/api/submissions)
    .get(function(req, res) {
        Submission.find(function(err, submissions) {
            if (err)
                res.send(err);

            res.json(submissions);
        })
    })

router.route('/submissions/:submission_id')

    // get the submission with that id (accessed at GET http://localhost:8080/api/submissions/:submission_id)
    .get(function(req, res) {
        Submission.findById(req.params.submission_id, function(err, submission) {
            if (err)
                res.send(err);
            res.json(submission);
        })
    })

    // update the submission with this id (accessed at PUT http://localhost:8080/api/submissions/:submission_id)
    .put(function(req, res) {

        // use our submission model to find the submission we want
        Submission.findById(req.params.submission_id, function(err, submission) {

            if (err)
                res.send(err);

            submission.name = req.body.name;  // update the submissions info

            // save the submission
            submission.save(function(err) {
                if (err)
                    res.send(err);

                res.json({ message: 'submission updated!' });
            });

        })
    })

    // delete the submission with this id (accessed at DELETE http://localhost:8080/api/submissions/:submission_id)
    .delete(function(req, res) {
        Submission.remove({
            _id: req.params.submission_id
        }, function(err, submission) {
            if (err)
                res.send(err);

            res.json({ message: 'submission successfully deleted' });
        });
    });


// REGISTER OUR ROUTES -------------------------------
// all of our routes will be prefixed with /api
app.use('/api', router);

// START THE SERVER
// =============================================================================
const server = app.listen(3000, () => {
  const host = server.address().address,
    port = server.address().port;

  console.log('API listening at http://%s:%s', host, port);
});


